package com.example.routefinder.model;

import java.util.*;
public class DijkstraPathfinder {

        public static List<Station> findShortestPath(Graph graph, String startName, String endName, double lineChangePenalty) {
            Station start = graph.getStation(startName);
            Station end = graph.getStation(endName);
            if (start == null || end == null) return null;

            PriorityQueue<PathNode> queue = new PriorityQueue<>();
            Map<Station, Double> visited = new HashMap<>();

            // Initial state
            queue.add(new PathNode(start, 0, new ArrayList<>(List.of(start)), null));

            while (!queue.isEmpty()) {
                PathNode current = queue.poll();

                // Stop if we've reached the destination
                if (current.station.equals(end)) {
                    return current.path;
                }

                // Skip if we already visited with a cheaper cost
                if (visited.containsKey(current.station) && visited.get(current.station) <= current.cost) continue;
                visited.put(current.station, current.cost);

                for (Connection connection : current.station.getConnections()) {
                    Station neighbor = connection.destination();
                    double baseCost = connection.distance();

                    double newCost = current.cost + baseCost;

                    // Add penalty if changing lines
                    if (current.currentLine != null && !current.currentLine.equals(connection.line())) {
                        newCost += lineChangePenalty;
                    }

                    List<Station> newPath = new ArrayList<>(current.path);
                    newPath.add(neighbor);

                    queue.add(new PathNode(neighbor, newCost, newPath, connection.line()));
                }
            }

            return null; // no path found
        }
    }

