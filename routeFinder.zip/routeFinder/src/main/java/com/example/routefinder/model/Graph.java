package com.example.routefinder.model;

import java.util.*;

public class Graph {
    private final Map<String, Station> stations = new HashMap<>();

    public Station getOrCreateStation(String name) {
        return stations.computeIfAbsent(name, Station::new);
    }

    public void addConnection(String from, String to, String line, String color, double distance) {
        Station start = getOrCreateStation(from);
        Station end = getOrCreateStation(to);

        start.addConnection(new Connection(end, line, color, distance));
        end.addConnection(new Connection(start, line, color, distance)); // bidirectional
    }

    public void addConnection(String start, String stop, String line, String color) {
        // Provide a default distance (can be updated later with real distances)
        double defaultDistance = 1.0;
        addConnection(start, stop, line, color, defaultDistance);
    }

    public List<String> getAllStationNames() {
        return stations.keySet().stream()
                .sorted()
                .toList();
    }

    public Collection<Station> getStations() {
        return stations.values();
    }

    public Station getStation(String name) {
        return stations.get(name);
    }

}

