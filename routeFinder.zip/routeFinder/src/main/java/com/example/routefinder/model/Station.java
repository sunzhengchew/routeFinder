package com.example.routefinder.model;

import java.util.ArrayList;
import java.util.List;

public class Station {
    private final String name;
    private final List<Connection> connections;
    private double latitude;  // decimal degrees
    private double longitude; // decimal degrees

    public Station(String name) {
        this.name = name;
        this.connections = new ArrayList<>();
    }

    public static double calculateEuclideanDistance(Station a, Station b) {
        double latDiff = a.getLatitude() - b.getLatitude();
        double lonDiff = a.getLongitude() - b.getLongitude();
        return Math.sqrt(latDiff * latDiff + lonDiff * lonDiff);
    }

    public void setCoordinates(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getName() {
        return name;
    }

    public List<Connection> getConnections() {
        return connections;
    }

    public void addConnection(Connection connection) {
        connections.add(connection);
    }

    @Override
    public String toString() {
        return name;
    }
}
