package com.example.routefinder;

import com.example.routefinder.model.Connection;
import com.example.routefinder.model.Station;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class ResultController {
    @FXML
    private Label routeSummaryLabel;
    @FXML
    private ListView<String> routeListView;
    @FXML
    private Label totalDistanceLabel;
    @FXML
    private Label penaltyLabel;
    @FXML
    private AnchorPane result_page;


    public void initData(String start, String end, List<Station> path, double totalDistance, double penalty) {
        routeSummaryLabel.setText("Route from " + start + " to " + end);
        totalDistanceLabel.setText(String.format("Total distance: %.2f km", totalDistance));
        penaltyLabel.setText("Line change penalty: " + penalty);

        routeListView.getItems().clear();

        for (int i = 0; i < path.size(); i++) {
            Station station = path.get(i);
            StringBuilder step = new StringBuilder((i + 1) + ". " + station.getName());

            if (i > 0) {
                Station prev = path.get(i - 1);
                Optional<Connection> connection = prev.getConnections().stream()
                        .filter(conn -> conn.destination().equals(station))
                        .findFirst();

                connection.ifPresent(conn -> step.append(" via ").append(conn.line()).append(" line"));
            }

            routeListView.getItems().add(step.toString());
        }
    }


    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("main.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void result_close() {
        System.exit(0);
    }

    public void result_minimise() {
        Stage stage = (Stage) result_page.getScene().getWindow();
        stage.setIconified(true);
    }

}
