module com.example.routefinder {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.ikonli.javafx;

    opens com.example.routefinder to javafx.fxml;
    exports com.example.routefinder;
}